<?php

return array (
  'environment' => 
  array (
    'classic' => 
    array (
      'back' => '',
      'install' => '',
      'save' => '',
      'templateTitle' => '',
      'title' => '',
    ),
    'errors' => 'Não foi possível gravar o arquivo .env, por favor crie-o manualmente.',
    'menu' => 
    array (
      'templateTitle' => '',
      'title' => '',
    ),
    'save' => 'Salvar .env',
    'success' => 'As configurações de seu arquivo .env foram gravadas.',
    'title' => 'Configurações de Ambiente',
    'wizard' => 
    array (
      'form' => 
      array (
        'app_debug_label' => '',
        'app_debug_label_false' => '',
        'app_debug_label_true' => '',
        'app_environment_label' => '',
        'app_environment_label_developement' => '',
        'app_environment_label_local' => '',
        'app_environment_label_other' => '',
        'app_environment_label_production' => '',
        'app_environment_label_qa' => '',
        'app_environment_placeholder_other' => '',
        'app_log_level_label' => '',
        'app_log_level_label_alert' => '',
        'app_log_level_label_critical' => '',
        'app_log_level_label_debug' => '',
        'app_log_level_label_emergency' => '',
        'app_log_level_label_error' => '',
        'app_log_level_label_info' => '',
        'app_log_level_label_notice' => '',
        'app_log_level_label_warning' => '',
        'app_name_label' => '',
        'app_name_placeholder' => '',
        'app_tabs' => 
        array (
          'broadcasting_label' => '',
          'broadcasting_placeholder' => '',
          'broadcasting_title' => '',
          'cache_label' => '',
          'cache_placeholder' => '',
          'mail_driver_label' => '',
          'mail_driver_placeholder' => '',
          'mail_encryption_label' => '',
          'mail_encryption_placeholder' => '',
          'mail_host_label' => '',
          'mail_host_placeholder' => '',
          'mail_label' => '',
          'mail_password_label' => '',
          'mail_password_placeholder' => '',
          'mail_port_label' => '',
          'mail_port_placeholder' => '',
          'mail_username_label' => '',
          'mail_username_placeholder' => '',
          'more_info' => '',
          'pusher_app_id_label' => '',
          'pusher_app_id_palceholder' => '',
          'pusher_app_key_label' => '',
          'pusher_app_key_palceholder' => '',
          'pusher_app_secret_label' => '',
          'pusher_app_secret_palceholder' => '',
          'pusher_label' => '',
          'queue_label' => '',
          'queue_placeholder' => '',
          'redis_host' => '',
          'redis_label' => '',
          'redis_password' => '',
          'redis_port' => '',
          'session_label' => '',
          'session_placeholder' => '',
        ),
        'app_url_label' => '',
        'app_url_placeholder' => '',
        'buttons' => 
        array (
          'install' => '',
        ),
        'db_connection_label' => '',
        'db_connection_label_mysql' => '',
        'db_connection_label_pgsql' => '',
        'db_connection_label_sqlite' => '',
        'db_connection_label_sqlsrv' => '',
        'db_host_label' => '',
        'db_host_placeholder' => '',
        'db_name_label' => '',
        'db_name_placeholder' => '',
        'db_password_label' => '',
        'db_password_placeholder' => '',
        'db_port_label' => '',
        'db_port_placeholder' => '',
        'db_username_label' => '',
        'db_username_placeholder' => '',
      ),
      'tabs' => 
      array (
        'environment' => '',
      ),
      'templateTitle' => '',
    ),
  ),
  'final' => 
  array (
    'console' => '',
    'env' => '',
    'exit' => 'Clique aqui para sair',
    'finished' => 'Aplicação foi instalada com sucesso',
    'log' => '',
    'migration' => '',
    'templateTitle' => '',
    'title' => 'Terminado',
  ),
  'finish' => 'Instalar',
  'next' => 'Próximo Passo',
  'permissions' => 
  array (
    'templateTitle' => '',
    'title' => 'Permissões',
  ),
  'requirements' => 
  array (
    'next' => '',
    'templateTitle' => '',
    'title' => 'Requisitos',
  ),
  'title' => 'Instalação de Laravel',
  'updater' => 
  array (
    'final' => 
    array (
      'exit' => '',
      'title' => '',
    ),
    'overview' => 
    array (
      'install_updates' => '',
    ),
    'title' => '',
    'welcome' => 
    array (
      'message' => '',
      'title' => '',
    ),
  ),
  'welcome' => 
  array (
    'message' => 'Bem-vindo ao assistente de configuração.',
    'next' => '',
    'templateTitle' => '',
    'title' => 'Bem-vindo ao Instalador',
  ),
);
