<!-- Start email footer area -->
<table border="0" cellpadding="0" cellspacing="0" style="width:100%;padding:15px 35px; background-color:#0E0E26;">
    <tr>
        <td align="center" valign="top">
            <table>
                <tr>
                    <td valign="top">
                        <div mc:edit="footer_icon_1" style="padding-right:15px;">
                            <a href="#"><img src="{{asset('assets/images/twitter-512.png')}}" width="40" alt=""></a>
                        </div>
                    </td>
                    <td valign="top">
                        <div mc:edit="footer_icon_2" style="padding-right:15px;">
                            <a href="#"><img src="{{asset('assets/images/facebook-512.png')}}" width="40" alt=""></a>
                        </div>
                    </td>
                    <td valign="top">
                        <div mc:edit="footer_icon_3" style="padding-right:15px;">
                            <a href="#"><img src="{{asset('assets/images/linkedin-512.png')}}" width="40" alt=""></a>
                        </div>
                    </td>
                    <td valign="top">
                        <div mc:edit="footer_icon_4" style="padding-right:15px;">
                            <a href="#"><img src="{{asset('assets/images/google-plus-512.png')}}" width="40" alt=""></a>
                        </div>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>

</td>
</tr>
</table>

</body>
</html>