<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:type" content="article" />
        <meta property="og:title" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta property="og:image" content="<?php echo e(show_image(1,'logo')); ?>">
    <meta property="og:site_name" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta property="og:url" content="<?php echo e(url()->current()); ?>"/>
    <meta itemprop="image" content="<?php echo e(show_image(1,'logo')); ?>" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/bootstrap.min.css')); ?>">
    <!-- metismenu CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/metisMenu.min.css')); ?>">
    <!-- fontawesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/font-awesome.min.css')); ?>">
    
    <link href="<?php echo e(asset('assets/common/toast/vanillatoasts.css')); ?>" rel="stylesheet" >
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/responsive.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
    <title><?php echo $__env->yieldContent('title'); ?> </title>
    <!-- Favicon and Touch Icons -->
    <link rel="shortcut icon" href="<?php echo e(landingPageImage('favicon','images/Pexeer.svg')); ?>/">
</head>

<body class="body-bg">
    <div class="auth-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

<!-- js file start -->

<!-- JavaScript -->
<script src="<?php echo e(asset('assets/common/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/metisMenu.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/common/toast/vanillatoasts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/sweetalert/sweetalert.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/js/main.js')); ?>"></script>

    <script>
        (function($) {
            "use strict";

            <?php if(session()->has('success')): ?>
                swal({
                    text: '<?php echo e(session('success')); ?>',
                    icon: "success",
                    buttons: false,
                    timer: 3000,
                });

            <?php elseif(session()->has('dismiss')): ?>
                swal({
                    text: '<?php echo e(session('dismiss')); ?>',
                    icon: "warning",
                    buttons: false,
                    timer: 3000,
                });

            <?php elseif($errors->any()): ?>
                <?php $__currentLoopData = $errors->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    swal({
                        text: '<?php echo e($error[0]); ?>',
                        icon: "error",
                        buttons: false,
                        timer: 3000,
                    });
                <?php break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        })(jQuery);

    </script>
<?php echo $__env->yieldContent('script'); ?>
<!-- End js file -->

</body>
</html>

<?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/auth/master.blade.php ENDPATH**/ ?>