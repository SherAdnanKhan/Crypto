<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li><?php echo e(__('Settings')); ?></li>
                    <li class="active-item"><?php echo e($title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management">
        <div class="row">
            <div class="col-12">
                <ul class="nav user-management-nav mb-3" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='general'): ?> active <?php endif; ?> nav-link " id="pills-user-tab"
                           data-toggle="pill" data-controls="general" href="#general" role="tab"
                           aria-controls="pills-user" aria-selected="true">
                            <span><?php echo e(__('General Settings')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='email'): ?> active <?php endif; ?> nav-link " id="pills-add-user-tab"
                           data-toggle="pill" data-controls="email" href="#email" role="tab"
                           aria-controls="pills-add-user" aria-selected="true">
                            <span><?php echo e(__('Email Settings')); ?> </span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='sms'): ?> active <?php endif; ?> nav-link " id="pills-sms-tab"
                           data-toggle="pill" data-controls="sms" href="#sms" role="tab" aria-controls="pills-sms"
                           aria-selected="true">
                            <span><?php echo e(__('Twillo Settings')); ?> </span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='referral'): ?> active <?php endif; ?> nav-link "
                           id="pills-suspended-user-tab" data-toggle="pill" data-controls="referral" href="#referral"
                           role="tab" aria-controls="pills-suspended-user" aria-selected="true">
                            <span><?php echo e(__('Referral Settings')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='payment'): ?> active <?php endif; ?> nav-link " id="pills-email-tab"
                           data-toggle="pill" data-controls="payment" href="#payment" role="tab"
                           aria-controls="pills-email" aria-selected="true">
                            <span><?php echo e(__('Coin Payment Settings')); ?></span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="<?php if(isset($tab) && $tab=='terms'): ?> active <?php endif; ?> nav-link " id="pills-email-tab"
                           data-toggle="pill" data-controls="terms" href="#terms" role="tab"
                           aria-controls="pills-email" aria-selected="true">
                            <span><?php echo e(__('Privacy Policy')); ?></span>
                        </a>
                    </li>
                </ul>
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane show <?php if(isset($tab) && $tab=='general'): ?>  active <?php endif; ?>" id="general"
                         role="tabpanel" aria-labelledby="pills-user-tab">
                        <?php echo $__env->make('admin.settings.setting.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='email'): ?> show active <?php endif; ?>" id="email"
                         role="tabpanel" aria-labelledby="pills-add-user-tab">
                        <?php echo $__env->make('admin.settings.setting.email', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='sms'): ?> show active <?php endif; ?>" id="sms" role="tabpanel"
                         aria-labelledby="pills-sms-tab">
                        <?php echo $__env->make('admin.settings.setting.twillo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='referral'): ?> show active <?php endif; ?>" id="referral"
                         role="tabpanel" aria-labelledby="pills-suspended-user-tab">
                        <?php echo $__env->make('admin.settings.setting.referral', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='payment'): ?> show active <?php endif; ?>" id="payment"
                         role="tabpanel" aria-labelledby="pills-email-tab">
                        <?php echo $__env->make('admin.settings.setting.coinpayment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="tab-pane <?php if(isset($tab) && $tab=='terms'): ?> show active <?php endif; ?>" id="terms"
                         role="tabpanel" aria-labelledby="pills-email-tab">
                        <?php echo $__env->make('admin.settings.setting.terms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        (function($) {
            "use strict";

            $('.nav-link').on('click', function () {
                $('.nav-link').removeClass('active');
                $(this).addClass('active');
                var str = '#' + $(this).data('controls');
                $('.tab-pane').removeClass('show active');
                $(str).addClass('show active');
            });
        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'setting', 'sub_menu'=>'general'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/admin/settings/general.blade.php ENDPATH**/ ?>