<div class="card cp-user-custom-card">
    <div class="card-body">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="cp-user-profile-header">
                    <h5><?php echo e(__('Reset Password')); ?></h5>
                </div>

            </div>
            <div class="col-lg-9">
                <div class="cp-user-profile-info">
                    <form method="POST" action="<?php echo e(route('changePasswordSave')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label><?php echo e(__('Current Password')); ?></label>
                            <input name="password" type="password"
                                   placeholder="<?php echo e(__('Current Password')); ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('New Password')); ?></label>
                            <input name="new_password" type="password"
                                   placeholder="<?php echo e(__('New Password')); ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Confirm New Password')); ?></label>
                            <input name="confirm_new_password" type="password"
                                   placeholder="<?php echo e(__('Re Enter New Password')); ?>"
                                   class="form-control">
                        </div>
                        <div class="form-group m-0">
                            <button class="btn profile-edit-btn"
                                    type="submit"><?php echo e(__('Change Password')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/user/profile/include/password.blade.php ENDPATH**/ ?>