<?php $__env->startSection('title', isset($title) ? $title : __('Forgot Password')); ?>

<?php $__env->startSection('content'); ?>
<div class="user-content-wrapper">
    <div>
        <div class="user-form">
            <div class="right">
                <div class="form-top">
                    <a class="auth-logo" href="javascript:">
                        <!--<img src="<?php echo e(asset('/assets/user/images/logo-top-.png')); ?>" class="img-fluid" alt="">-->
                    </a>
                    <p><?php echo e(__('Forgot Password')); ?></p>
                </div>
                <?php echo e(Form::open(['route' => 'sendForgotMail', 'files' => true])); ?>

                <div class="form-group">
                    <label><?php echo e(__('Email address')); ?></label>
                    <input type="email" name="email" class="form-control" placeholder="<?php echo e(__('Your email here')); ?>">
                </div>
                <button type="submit" class="btn btn-primary nimmu-user-sibmit-button"><?php echo e(__('Send')); ?></button>
                <?php echo e(Form::close()); ?>

                <div class="form-bottom text-center">
                    <p><?php echo e(__('Return to ')); ?> <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Sign in')); ?></a></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.master',['menu'=>'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/auth/forgot_password.blade.php ENDPATH**/ ?>