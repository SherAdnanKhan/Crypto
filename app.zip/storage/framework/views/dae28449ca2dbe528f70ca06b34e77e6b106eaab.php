<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-md-12">
                <ul>
                    <li><?php echo e(__('Notification Management')); ?></li>
                    <li class="active-item"><?php echo e($title); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management">
        <div class="row">
            <div class="col-12">
                <div class="profile-info-form">
                <div class="card-body">
                    <form action="<?php echo e(route('sendNotificationProcess')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12 mt-20">
                                <div class="form-group">
                                    <label for="firstname"><?php echo e(__('Title')); ?></label>
                                    <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(old('title')); ?>"  name="title" placeholder="<?php echo e(__('Notification Title')); ?>">
                                </div>
                            </div>
                            <div class="col-md-12 mt-20">
                                <div class="form-group">
                                    <label for="firstname"><?php echo e(__('Notification Body')); ?></label>
                                    <textarea name="notification_body" id="" placeholder="<?php echo e(__('Notification body')); ?>" class="textarea form-control"><?php echo e(old('notification_body')); ?></textarea>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="card mail-card">
                                    <div class="card-body">
                                        <button class="btn email-submit-btn"> <?php echo e(__('Send')); ?> </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'notification', 'sub_menu'=>'notify'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/admin/notification/notification.blade.php ENDPATH**/ ?>