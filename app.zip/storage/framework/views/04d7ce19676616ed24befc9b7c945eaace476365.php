<div class="header-bar">
    <div class="table-title">
        <h3><?php echo e(__('Email Setup')); ?></h3>
    </div>
</div>
<div class="profile-info-form">
    <form action="<?php echo e(route('adminSaveEmailSettings')); ?>" method="post"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Email Host')); ?></label>
                    <input class="form-control" type="text" name="mail_host"
                           placeholder="<?php echo e(__('Host')); ?>" value="<?php echo e($settings['mail_host']); ?>">
                </div>
            </div>
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Email Port')); ?></label>
                    <input class="form-control" type="text" name="mail_port"
                           placeholder="<?php echo e(__('Port')); ?>" value="<?php echo e($settings['mail_port']); ?>">
                </div>
            </div>
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Email Username')); ?></label>
                    <input class="form-control" type="text" name="mail_username"
                           placeholder="<?php echo e(__('Username')); ?>"
                           value="<?php echo e(isset($settings['mail_username']) ? $settings['mail_username'] : ''); ?>">
                </div>
            </div>
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Email Password')); ?></label>
                    <input class="form-control" type="password" name="mail_password"
                           placeholder="<?php echo e(__('Password')); ?>"
                           value="<?php echo e($settings['mail_password']); ?>">
                </div>
            </div>
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Mail Encryption')); ?></label>
                    <input class="form-control" type="text" name="mail_encryption"
                           placeholder="<?php echo e(__('Encryption')); ?>"
                           value="<?php echo e(isset($settings['mail_encryption']) ? $settings['mail_encryption'] : ''); ?>">
                </div>
            </div>
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Mail Form Address')); ?></label>
                    <input class="form-control" type="text" name="mail_from_address"
                           placeholder="<?php echo e(__('Mail from address')); ?>"
                           value="<?php echo e(isset($settings['mail_from_address']) ? $settings['mail_from_address'] : ''); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-2 col-12 mt-20">
                <button type="submit" class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/admin/settings/setting/email.blade.php ENDPATH**/ ?>