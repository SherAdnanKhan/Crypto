<!DOCTYPE HTML>
<html class="no-js" lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="The Highly Secured Bitcoin Wallet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:type" content="article" />
    <meta property="og:title" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta property="og:image" content="<?php echo e(show_image(Auth::user()->id,'logo')); ?>">
    <meta property="og:site_name" content="<?php echo e(allsetting('app_title')); ?>"/>
    <meta property="og:url" content="<?php echo e(url()->current()); ?>"/>
    <meta itemprop="image" content="<?php echo e(show_image(Auth::user()->id,'logo')); ?>" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/bootstrap.min.css')); ?>">
    <!-- metismenu CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/metisMenu.min.css')); ?>">
    <!-- fontawesome CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/font-awesome.min.css')); ?>">
    
    <link href="<?php echo e(asset('assets/common/toast/vanillatoasts.css')); ?>" rel="stylesheet" >
    <!-- Datatable CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/datatable/datatables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/datatable/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/datatable/dataTables.jqueryui.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/datatable/dataTables.responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/datatable/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/css/css-circular-prog-bar.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/datepicker/css/bootstrap-datepicker.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/dropify/dropify.css')); ?>">
    
    <link href="<?php echo e(asset('assets/common/multiselect/tokenize2.css')); ?>" rel="stylesheet">
    <!-- select -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/multiselect/bootstrap-select.min.css')); ?>">

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/common/summernote/summernote.min.css')); ?>">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/style.css')); ?>">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/responsive.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon and Touch Icons -->
    <link rel="shortcut icon" href="<?php echo e(landingPageImage('favicon','images/Pexeer.svg')); ?>/">
</head>

<body class="body-bg">
<!-- Start sidebar -->
<div class="sidebar">
    <!-- logo -->
    <div class="logo">
        <a href="<?php echo e(route('adminDashboard')); ?>">
            <img src="<?php echo e(show_image(Auth::user()->id,'logo')); ?>" class="img-fluid" alt="">
        </a>
    </div><!-- /logo -->

    <!-- sidebar menu -->
    <div class="sidebar-menu">
        <nav>
            <ul id="metismenu">
                <li class="<?php if(isset($menu) && $menu == 'dashboard'): ?> active-page <?php endif; ?>">
                    <a href="<?php echo e(route('adminDashboard')); ?>">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/dashboard.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Dashboard')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'users'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/user.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('User Management')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'users'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'user'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminUsers')); ?>"><?php echo e(__('User')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'pending_id'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminUserIdVerificationPending')); ?>"><?php echo e(__('Pending ID Verification')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'coin'): ?> active-page <?php endif; ?>">
                    <a href="<?php echo e(route('adminCoinList')); ?>">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/coin.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Coin List')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'pocket'): ?> active-page <?php endif; ?>">
                    <a href="<?php echo e(route('adminWalletList')); ?>">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/wallet.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Wallet List')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'transaction'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/Transaction-1.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Transaction History')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'transaction'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'transaction_all'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminTransactionHistory')); ?>"><?php echo e(__('All Transaction')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'transaction_withdrawal'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminPendingWithdrawal')); ?>"><?php echo e(__('Pending Withdrawal')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'offer'): ?> active-page  <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/My-Offer-1.svg')); ?>" class="img-fluid" alt="">
                        </span>
                        <span class="name"><?php echo e(__('Offer List')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'offer'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'buy_offer'): ?> submenu-active <?php endif; ?>"><a href="<?php echo e(route('offerList',BUY)); ?>"><?php echo e(__('Buy Offer')); ?></a></li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'sell_offer'): ?> submenu-active <?php endif; ?>"><a href="<?php echo e(route('offerList',SELL)); ?>"><?php echo e(__('Sell Offer')); ?></a></li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'order'): ?> active-page  <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon">
                            <img src="<?php echo e(asset('assets/user/images/sidebar-icons/Trade-1.svg')); ?>" class="img-fluid" alt="">
                        </span>
                        <span class="name"><?php echo e(__('Trade')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'order'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'order'): ?> submenu-active  <?php endif; ?>"><a href="<?php echo e(route('orderList')); ?>"><?php echo e(__('Trade List')); ?></a></li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'dispute'): ?> submenu-active <?php endif; ?>"><a href="<?php echo e(route('orderDisputeList')); ?>"><?php echo e(__('Dispute List')); ?></a></li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'payment_method'): ?> active-page <?php endif; ?>">
                    <a href="<?php echo e(route('paymentMethodList')); ?>">
                        <span class="icon"><img src="<?php echo e(asset('assets/user/images/sidebar-icons/Payment-method-1.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Payment Method')); ?></span>
                    </a>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'notification'): ?> active-page <?php endif; ?>">

                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/Notification.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Notification')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'notification'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'notify'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('sendNotification')); ?>"><?php echo e(__('Notification')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'email'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('sendEmail')); ?>"><?php echo e(__('Bulk Email')); ?></a>
                        </li>
                    </ul>
                </li>
                <li class="<?php if(isset($menu) && $menu == 'setting'): ?> active-page <?php endif; ?>">
                    <a href="#" aria-expanded="true">
                        <span class="icon"><img src="<?php echo e(asset('assets/admin/images/sidebar-icons/settings.svg')); ?>" class="img-fluid" alt=""></span>
                        <span class="name"><?php echo e(__('Settings')); ?></span>
                    </a>
                    <ul class="<?php if(isset($menu) && $menu == 'setting'): ?>  mm-show  <?php endif; ?>">
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'general'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminSettings')); ?>"><?php echo e(__('General Settings')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'landing'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('landingSettings')); ?>"><?php echo e(__('Landing Settings')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'testimonial'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminTestimonialList')); ?>"><?php echo e(__('Testimonial')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'subscribers'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('subscribers')); ?>"><?php echo e(__('Subscribers')); ?></a>
                        </li>
                        <li class="<?php if(isset($sub_menu) && $sub_menu == 'faq'): ?> submenu-active <?php endif; ?>">
                            <a href="<?php echo e(route('adminFaqList')); ?>"><?php echo e(__('FAQ')); ?></a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div><!-- /sidebar menu -->

</div>
<!-- End sidebar -->
<!-- top bar -->
<div class="top-bar">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-between">
            <div class="col-xl-1 col-md-2 col-3 top-bar-logo top-bar-logo-hide">
                <div class="logo">
                    <a href="<?php echo e(route('adminDashboard')); ?>"><img src="<?php echo e(show_image(Auth::user()->id,'logo')); ?>" class="img-fluid logo-large" alt=""></a>
                    <a href="<?php echo e(route('adminDashboard')); ?>"><img src="<?php echo e(show_image(Auth::user()->id,'logo')); ?>" class="img-fluid logo-small" alt=""></a>
                </div>
            </div>
            <div class="col-xl-1 col-md-2 col-3">
                <div class="menu-bars">
                    <img src="<?php echo e(asset('assets/admin/images/sidebar-icons/menu.svg')); ?>" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-xl-10 col-md-8 col-6">
                <div class="top-bar-right">
                    <ul>
                        <li>
                            <div class="btn-group profile-dropdown">
                                <button type="button" class="btn dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="cp-user-avater">
                                        <span class="cp-user-img">
                                            <img src="<?php echo e(show_image(Auth::user()->id,'user')); ?>" class="img-fluid" alt="">
                                        </span>
                                        <span class="name"><?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?></span>
                                    </span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <span class="big-user-thumb">
                                        <img src="<?php echo e(show_image(Auth::user()->id,'user')); ?>" class="img-fluid" alt="">
                                    </span>
                                    <div class="user-name">
                                        <p><?php echo e(Auth::user()->first_name.' '.Auth::user()->last_name); ?></p>
                                    </div>
                                    <button class="dropdown-item" type="button"><a href="<?php echo e(route('adminProfile')); ?>"><i class="fa fa-user-circle-o"></i> <?php echo e(__('Profile')); ?></a></button>
                                    <button class="dropdown-item" type="button"><a href="<?php echo e(route('logOut')); ?>"><i class="fa fa-sign-out"></i> <?php echo e(__('Logout')); ?></a></button>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /top bar -->

<!-- main wrapper -->
<div class="main-wrapper">
    <div class="container-fluid">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>
<!-- /main wrapper -->

<!-- js file start -->

<!-- JavaScript -->
<script src="<?php echo e(asset('assets/common/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/metisMenu.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/common/js/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/jquery.circlechart.js')); ?>"></script>


<script src="<?php echo e(asset('assets/common/toast/vanillatoasts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/sweetalert/sweetalert.min.js')); ?>"></script>
<!-- Datatable -->
<script src="<?php echo e(asset('assets/common/js/datatable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/datatable/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/datatable/dataTables.jqueryui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/datatable/dataTables.responsive.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/js/datatable/jquery.dataTables.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/common/datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>


<script src="<?php echo e(asset('assets/common/summernote/summernote.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/common/multiselect/bootstrap-select.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/common/dropify/dropify.js')); ?>"></script>
<script src="<?php echo e(asset('assets/common/dropify/form-file-uploads.js')); ?>"></script>

<script src="<?php echo e(asset('assets/admin/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('assets/common/multiselect/tokenize2.js')); ?>"></script>


<script>
    (function($) {
        "use strict";

        <?php if(session()->has('success')): ?>
            swal({
                text: '<?php echo e(session('success')); ?>',
                icon: "success",
                buttons: false,
                timer: 3000,
            });

        <?php elseif(session()->has('dismiss')): ?>
            swal({
                text: '<?php echo e(session('dismiss')); ?>',
                icon: "warning",
                buttons: false,
                timer: 3000,
            });

        <?php elseif($errors->any()): ?>
            <?php $__currentLoopData = $errors->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                swal({
                    text: '<?php echo e($error[0]); ?>',
                    icon: "error",
                    buttons: false,
                    timer: 3000,
                });
            <?php break; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        $('#btEditor').summernote({height: 300});
        $('#btEditor2').summernote({height: 400});
        $('#btEditor3').summernote({height: 400});
        $('#btEditor4').summernote({height: 400});
    })(jQuery);
</script>

<?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/admin/master.blade.php ENDPATH**/ ?>