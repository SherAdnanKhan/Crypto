<div class="row">
    <div class="col-xl-4 mb-xl-0 mb-4">
        <div class="card cp-user-custom-card">
            <div class="card-body">
                <div class="user-profile-area">
                    <div class="user-profile-img">
                        <img src="<?php echo e(show_image($user->id,'user')); ?>" class="img-fluid" alt="">
                    </div>
                    <div class="user-cp-user-profile-info">
                        <h4><?php echo e($user->first_name.' '.$user->last_name); ?></h4>
                        <p><?php echo e($user->email); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-8">
        <div class="card cp-user-custom-card">
            <div class="card-body">
                <div class="cp-user-profile-header">
                    <h5><?php echo e(__('Profile Information')); ?></h5>
                </div>
                <div class="cp-user-profile-info">
                    <ul>
                        <li>
                            <span><?php echo e(__('Name')); ?></span>
                            <span class="cp-user-dot">:</span>
                            <span><?php echo e($user->first_name.' '.$user->last_name); ?></span>
                        </li>
                        <li>
                            <span><?php echo e(__('Country')); ?></span>
                            <span class="cp-user-dot">:</span>
                            <span>
                                <?php if(!empty($user->country)): ?>
                                    <?php echo e(countrylist(strtoupper($user->country))); ?>

                                <?php endif; ?>
                            </span>
                        </li>
                        <li>
                            <span><?php echo e(__('Email')); ?></span>
                            <span class="cp-user-dot">:</span>
                            <span><?php echo e($user->email); ?></span>
                        </li>
                        <li>
                            <span><?php echo e(__('Email Verification')); ?></span>
                            <span class="cp-user-dot">:</span>
                            <span><?php echo e(statusAction($user->is_verified)); ?></span>
                        </li>
                        <li>
                            <span><?php echo e(__('Phone')); ?></span>
                            <span class="cp-user-dot">:</span>
                            <span><?php echo e($user->phone); ?></span>
                        </li>
                        <li>
                            <span><?php echo e(__('Role')); ?></span>
                            <span class="cp-user-dot">:</span>
                            <span><?php echo e(userRole($user->role)); ?></span>
                        </li>
                        <li>
                            <span><?php echo e(__('Active Status')); ?></span>
                            <span class="cp-user-dot">:</span>
                            <span><?php echo e(statusAction($user->status)); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/user/profile/include/profile.blade.php ENDPATH**/ ?>