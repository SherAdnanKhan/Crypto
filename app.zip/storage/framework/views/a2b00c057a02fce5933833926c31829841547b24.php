<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 mb-xl-0 mb-4">
            <div class="card cp-user-custom-card">
                <div class="card-body">
                    <div class="cp-user-buy-coin-content-area">
                        <div class="cp-user-coin-info">
                            <form action="<?php echo e(route('marketPlace')); ?>" method="GET" enctype="multipart/form-data" id="">
                                <?php echo csrf_field(); ?>
                                <div class="row align-items-end">
                                <div class="col-xl-2 col-sm-4 col-lg-4">
                                    <div class="cp-user-payment-type mb-3">
                                        <h3><?php echo e(__('Want to')); ?></h3>
                                        <select name="offer_type" class=" form-control" >
                                            <?php $__currentLoopData = buy_sell(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(isset($offer_type) && $offer_type == $key): ?> selected <?php endif; ?> value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-2 col-sm-4 col-lg-4">
                                    <div class="cp-user-payment-type mb-3">
                                        <h3><?php echo e(__('Coin Type')); ?></h3>
                                        <select name="coin_type" class=" form-control" >
                                            <?php if(isset($coins[0])): ?>
                                                <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php if(isset($coins_type) && $coins_type == $coin->type): ?> selected <?php endif; ?> value="<?php echo e($coin->type); ?>"><?php echo e($coin->type); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-sm-4 col-lg-4">
                                    <div class="cp-user-payment-type mb-3">
                                        <h3><?php echo e(__('Location')); ?></h3>
                                        <select name="country" class=" form-control" id="country">
                                            <option value="any"><?php echo e(__('Anywhere')); ?></option>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(isset($country) && $country == $key): ?> selected <?php endif; ?> value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-3 col-sm-4 col-lg-4">
                                    <div class="cp-user-payment-type mb-3" id="">
                                        <h3><?php echo e(__('Payment Method')); ?></h3>
                                        <select name="payment_method" class=" form-control" id="select-payment-method" >
                                            <option value="any"><?php echo e(__('Any Payment Method')); ?></option>
                                            <?php if(isset($payment_methods[0])): ?>
                                                <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($country == 'any'): ?>
                                                        <option <?php if(isset($pmethod) && $pmethod == $payment_method->id): ?> selected <?php endif; ?> value="<?php echo e($payment_method->id); ?>"><?php echo e($payment_method->name); ?></option>
                                                    <?php elseif(is_accept_payment_method($payment_method->id,$country)): ?>
                                                        <option <?php if(isset($pmethod) && $pmethod == $payment_method->id): ?> selected <?php endif; ?> value="<?php echo e($payment_method->id); ?>"><?php echo e($payment_method->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-2 col-sm-4 col-lg-4">
                                    <div class="cp-user-payment-type text-right mr-3 mb-3">
                                        <h3></h3>
                                        <button type="submit" class="btn theme-btn"><?php echo e(__('Filter')); ?></button>
                                    </div>
                                </div>

                            </div>
                            </form>
                            <div class="row mt-4">
                                <div class="col-sm-12">
                                    <div class="cp-user-card-header-area">
                                        <div class="title">
                                            <h4 id="list_title"><?php echo e(__('Buy ')); ?> <?php echo e($coins_type); ?> <?php echo e(__(' from these sellers')); ?></h4>
                                        </div>
                                    </div>
                                    <div class="cp-user-wallet-table table-responsive buy-table crypto-exchange-table">
                                        <table class="table">
                                            <tbody>
                                            <?php if(isset($sells[0])): ?>
                                                <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <h4><a href="<?php echo e(route('userTradeProfile',$sell->user_id)); ?>"><?php echo e($sell->user->first_name.' '.$sell->user->last_name); ?></a></h4>
                                                            <p> <?php echo e(count_trades($sell->user->id)); ?> <?php echo e(__(' trades')); ?></p>
                                                        </td>
                                                        <td>
                                                            <h4><?php echo e(__('Payment System')); ?></h4>
                                                                <?php if(isset($sell->payment($sell->id)[0])): ?>
                                                                <ul>
                                                                    <?php $__currentLoopData = $sell->payment($sell->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($country == 'any'): ?>
                                                                            <li>
                                                                                <span><img src="<?php echo e($sell_payment->payment_method->image); ?>" alt=""></span>
                                                                                <?php echo e($sell_payment->payment_method->name); ?>

                                                                            </li>
                                                                        <?php elseif(is_accept_payment_method($sell_payment->payment_method_id,$country)): ?>
                                                                            <li>
                                                                                <span><img src="<?php echo e($sell_payment->payment_method->image); ?>" alt=""></span>
                                                                                <?php echo e($sell_payment->payment_method->name); ?>

                                                                            </li>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </ul>
                                                                <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <h4><?php echo e(countrylist($sell->country)); ?></h4>
                                                            <p><?php echo e($sell->address); ?></p>

                                                        </td>
                                                        <td>
                                                            <h4><?php echo e(number_format($sell->minimum_trade_size,2). ' '.$sell->currency); ?> <?php echo e(__(' to ')); ?> <?php echo e(number_format($sell->maximum_trade_size,2). ' '.$sell->currency); ?></h4>
                                                        </td>
                                                        <td>
                                                            <?php if($sell->rate_type == RATE_TYPE_DYNAMIC): ?>
                                                                <p class="normal"><?php echo e(number_format($sell->coin_rate,2).' '.$sell->currency); ?></p>
                                                                <p class="mute"> <?php echo e(number_format($sell->rate_percentage,2)); ?> % <?php echo e(price_rate_type($sell->price_type)); ?> <?php echo e(__(' Market')); ?></p>

                                                            <?php else: ?>
                                                                <p class="normal"><?php echo e(number_format($sell->coin_rate,2).' '.$sell->currency); ?></p>
                                                                <p class="mute">  <?php echo e(__(' Static Rate')); ?></p>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="text-right">
                                                            <a href="<?php echo e(route('openTrade',['buy',$sell->id])); ?>"><button class="btn theme-btn"><?php echo e(__('Buy Now')); ?></button></a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr>
                                                    <th colspan="7" class="text-center"><?php echo e(__('No data available')); ?></th>
                                                </tr>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                        <?php if(isset($sells[0])): ?>
                                            <div class="pull-right address-pagin">
                                                <?php echo e($sells->appends(request()->input())->links()); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-4">
                                <div class="col-sm-12">
                                    <div class="cp-user-card-header-area">
                                        <div class="title">
                                            <h4 id="list_title"><?php echo e(__('Sell ')); ?> <?php echo e($coins_type); ?> <?php echo e(__(' to these sellers')); ?></h4>
                                        </div>
                                    </div>
                                    <div class="cp-user-wallet-table table-responsive buy-table crypto-exchange-table">
                                        <table class="table">
                                            <tbody>
                                            <?php if(isset($buys[0])): ?>
                                                <?php $__currentLoopData = $buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <h4><a href="<?php echo e(route('userTradeProfile',$buy->user_id)); ?>"><?php echo e($buy->user->first_name.' '.$buy->user->last_name); ?></a></h4>
                                                            <p> <?php echo e(count_trades($buy->user->id)); ?> <?php echo e(__(' trades')); ?></p>
                                                        </td>
                                                        <td>
                                                            <h4><?php echo e(__('Payment System')); ?></h4>
                                                                <?php if(isset($buy->payment($buy->id)[0])): ?>
                                                                    <ul class="payment-system-list">
                                                                        <?php $__currentLoopData = $buy->payment($buy->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy_payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($country == 'any'): ?>
                                                                                <li>
                                                                                    <span><img src="<?php echo e($buy_payment->payment_method->image); ?>" alt=""></span><?php echo e($buy_payment->payment_method->name); ?>

                                                                                </li>
                                                                            <?php elseif(is_accept_payment_method($buy_payment->payment_method_id,$country)): ?>
                                                                                <li>
                                                                                    <span><img src="<?php echo e($buy_payment->payment_method->image); ?>" alt=""></span><?php echo e($buy_payment->payment_method->name); ?>

                                                                                </li>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </ul>
                                                                <?php endif; ?>
                                                        </td>
                                                        <td><h4><?php echo e(countrylist($buy->country)); ?></h4></td>
                                                        <td>
                                                            <?php echo e(number_format($buy->minimum_trade_size,2). ' '.$buy->currency); ?> <?php echo e(__(' to ')); ?> <?php echo e(number_format($buy->maximum_trade_size,2). ' '.$buy->currency); ?>

                                                        </td>
                                                        <td>
                                                            <?php if($buy->rate_type == RATE_TYPE_DYNAMIC): ?>
                                                                <p class="normal"><?php echo e(number_format($buy->coin_rate,2).' '.$buy->currency); ?></p>
                                                                <p class="mute"> <?php echo e(number_format($buy->rate_percentage,2)); ?> % <?php echo e(price_rate_type($buy->price_type)); ?> <?php echo e(__(' Market')); ?></p>

                                                            <?php else: ?>
                                                                <p class="normal"><?php echo e(number_format($buy->coin_rate,2).' '.$buy->currency); ?></p>
                                                                <p class="mute">  <?php echo e(__(' Static Rate')); ?></p>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td class="text-right">
                                                            <a href="<?php echo e(route('openTrade',['sell',$buy->id])); ?>"><button class="btn theme-btn"><?php echo e(__('Sell Now')); ?></button></a>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="7" class="text-center"><?php echo e(__('No data available')); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            </tbody>
                                        </table>
                                        <?php if(isset($buys[0])): ?>
                                            <div class="pull-right address-pagin">
                                                <?php echo e($buys->appends(request()->input())->links()); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade " id="popUpModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-content">
                                <p>
                                    <?php if(isset($settings['terms_condition'])): ?>
                                        <?php echo $settings['terms_condition']; ?>

                                    <?php else: ?>
                                        "Lorem ipsum dolor sit amet, consectetur adipisicing elit. A animi distinctio dolore
                                        ex, harum illum in inventore ipsam iusto laborum maiores minima minus modi nulla
                                        odio odit pariatur porro quod ratione reiciendis rerum tempore velit veritatis!
                                        Consequuntur corporis dolores ea eaque, error excepturi id ipsam iste magnam
                                        mollitia non nulla obcaecati placeat possimus provident quibusdam quod quos tempora.
                                        A autem cumque cupiditate, debitis distinctio, esse harum labore nobis nulla
                                        perferendis quasi tempora voluptas? Consequatur corporis cum reiciendis! A
                                        accusantium aperiam aspernatur at autem debitis delectus dolores error est eum
                                        eveniet ex facilis id itaque, laudantium magnam minima natus neque nihil nisi nobis
                                        numquam officiis perferendis quia quidem quisquam, repellendus reprehenderit saepe
                                        tempora ullam? Esse eum illum, neque obcaecati officiis quae repudiandae sequi. Aut
                                        corporis debitis dignissimos error, est fugit iste laboriosam laudantium maiores nam
                                        nobis quae quidem quod repellat repellendus rerum similique soluta voluptatem
                                        voluptates voluptatibus. Consequatur dolorem eos id illo numquam odit perspiciatis
                                        recusandae repudiandae suscipit unde. Aliquam, amet aperiam consequuntur corporis
                                        cum delectus dignissimos, ex, molestias obcaecati placeat quam quisquam quos rerum
                                        temporibus ut veritatis voluptates? Dolore facilis illum impedit natus quae?
                                        Accusantium adipisci asperiores atque cum delectus esse, eum ex illo in incidunt
                                        minima molestiae natus nemo neque nisi odio officiis possimus provident quae quaerat
                                        quas reiciendis rem repudiandae sint voluptas voluptate, voluptatem. Aspernatur,
                                        harum mollitia necessitatibus porro sit suscipit unde? Animi deleniti ducimus ea,
                                        eius harum ipsum magnam nesciunt officiis reiciendis vel! Aliquid atque deserunt
                                        fugit laborum qui quisquam saepe sapiente sequi vero voluptate. Aliquam aliquid
                                        consequatur culpa in incidunt odio quibusdam, temporibus voluptatibus. Alias aliquid
                                        commodi labore placeat tempora! Ad aperiam consequuntur, deserunt dolore eligendi
                                        magnam nisi pariatur quam quidem, repellat reprehenderit saepe sequi vero. Culpa
                                        debitis et minus modi nesciunt quidem, rem saepe? Accusantium at cumque enim
                                        exercitationem, optio pariatur provident quo veniam! Accusamus alias aliquam amet
                                        blanditiis consectetur cupiditate delectus deleniti deserunt distinctio dolor eaque
                                        esse excepturi exercitationem expedita illo inventore iure labore laudantium minus,
                                        necessitatibus non obcaecati odit optio pariatur perferendis possimus quae quidem
                                        quos repudiandae saepe sapiente sequi, sit, temporibus tenetur unde vel voluptatem.
                                        Aliquam autem consequuntur ducimus, earum eum eveniet excepturi inventore itaque
                                        labore laboriosam laborum necessitatibus nulla numquam porro quas qui ratione sed
                                        totam ut voluptatum? Corporis nostrum recusandae voluptas. Corporis iste quia rerum.
                                        Amet at autem beatae blanditiis consequatur culpa delectus dolor earum eligendi est
                                        exercitationem facere fuga fugit hic illo illum, ipsum iure modi molestiae,
                                        necessitatibus neque numquam porro praesentium quas quia quibusdam quos recusandae
                                        sit voluptatem voluptates? Accusamus accusantium alias architecto aspernatur
                                        assumenda at consectetur consequatur culpa cumque dolor earum eius eligendi enim
                                        error est ex illo incidunt maxime minus molestias nisi nulla quia quibusdam quos
                                        repellendus vel vero, voluptas! Animi aut blanditiis consequatur cumque cupiditate
                                        dicta dolor dolore dolores eaque earum excepturi facere, facilis hic impedit in ipsa
                                        ipsum iusto labore libero magnam modi necessitatibus nesciunt, nobis officia,
                                        placeat possimus quae quam qui quos repudiandae saepe totam voluptate voluptatum.
                                        Ratione, unde, vel! Aperiam aspernatur commodi ea et ex libero neque pariatur
                                        provident! Dolorem doloribus, minus."
                                    <?php endif; ?>
                                </p>
                            </div>
                            <div class="border-top pt-4">
                                <p>Please read this terms and condition carefully. It is necessary that
                                    you
                                    read and understand the information</p>
                            </div>
                            <form class="mt-4" action="<?php echo e(route('saveUserAgreement')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-check">
                                    <input class="form-check-input d-none" type="radio" name="agree_terms"
                                           id="popupRadio1"
                                           value="<?php echo e(AGREE); ?>">
                                    <label class="form-check-label" for="popupRadio1"><?php echo e(__('Understand and Agree')); ?></label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input d-none" type="radio" name="agree_terms"
                                           id="popupRadio2"
                                           value="<?php echo e(NOT_AGREE); ?>">
                                    <label class="form-check-label" for="popupRadio2"><?php echo e(__('Not agree')); ?></label>
                                </div>
                                <div class="form-group mt-4">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                    <button type="submit" class="btn theme-btn"><?php echo e(__('Continue')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

        (function($) {
            "use strict";

            $('#country').on('change',function () {
                var country_id = $(this).val();

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('getCountryPaymentMethod')); ?>",
                    data: {
                        '_token': "<?php echo e(csrf_token()); ?>",
                        'country': country_id
                    },
                    dataType: 'JSON',

                    success: function (data) {
                        console.log(data)
                        $('#select-payment-method').html("<option value=\"any\"><?php echo e(__('Any Payment Method')); ?></option>"+data.data)
                    }
                })
            });

            <?php if(Auth::user() && Auth::user()->agree_terms == STATUS_DEACTIVE): ?>

                $(window).on('load', function () {
                    $('#popUpModal').modal('show');
                });

            <?php endif; ?>

        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',[ 'menu'=>'marketplace'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/user/marketplace/market/marketplace.blade.php ENDPATH**/ ?>