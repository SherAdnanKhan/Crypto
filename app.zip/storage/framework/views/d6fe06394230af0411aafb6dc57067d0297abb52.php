<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card cp-user-custom-card">
                <div class="card-body">
                    <div class="cp-user-card-header-area cp-user-card-header-bb">
                        <h4><?php echo e(__('FAQs')); ?></h4>
                    </div>
                    <div id="accordion" class="accordion">
                        <div class="row ">
                            <?php if(isset($items[0])): ?>
                                <?php $i=1 ?>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-6">
                                        <div class="cp-user-referral-content">
                                            <div class="card">
                                                <div class="card-header" id="headingOne">
                                                    <h5 class="mb-0">
                                                        <button class="btn btn-link collapsed" data-toggle="collapse"
                                                                data-target="#collapseOne<?php echo e($item->id); ?>"
                                                                aria-expanded="true" aria-controls="collapseOne">
                                                            <?php echo clean($item->question); ?>

                                                        </button>
                                                    </h5>
                                                </div>
                                                <div id="collapseOne<?php echo e($item->id); ?>" class="collapse <?php if($i == 1): ?> show <?php endif; ?>" aria-labelledby="headingOne"
                                                     data-parent="#accordion">
                                                    <div class="card-body">
                                                        <?php echo clean($item->answer); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php $i++ ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="col-md-12">
                                    <p class="text-center text-danger"><?php echo e(__('No data found')); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'setting', 'sub_menu'=>'faq'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/user/faq/index.blade.php ENDPATH**/ ?>