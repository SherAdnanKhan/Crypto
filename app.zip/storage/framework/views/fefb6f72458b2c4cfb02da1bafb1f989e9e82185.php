<div class="card cp-user-custom-card">
    <div class="card-body">
        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="cp-user-profile-header">
                    <h5><?php echo e(__('Phone Verification')); ?></h5>
                </div>
                <div class="cp-user-profile-info">
                    <form method="post" action="<?php echo e(route('phoneVerify')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="number"><?php echo e(__('Phone number')); ?></label>
                            <div class="code-list">
                                <?php if(!empty($user->phone)): ?>
                                    <input type="text" readonly value="<?php echo e(Auth::user()->phone); ?>"
                                           class="form-control" id="">
                                    <?php if((Auth::user()->phone_verified == 0 )  && (!empty(\Illuminate\Support\Facades\Cookie::get('code')))): ?>
                                        <a href="<?php echo e(route('sendSMS')); ?>"
                                           class="btn btn-primary mt-3"><?php echo e(__('Resend SMS')); ?></a>
                                        <p><?php echo e(__('Did not receive code?')); ?></p>
                                    <?php elseif(Auth::user()->phone_verified == 1 ): ?>
                                        <span class="verified"><?php echo e(__('Verified')); ?></span>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('sendSMS')); ?>"
                                           class="btn btn-primary mt-3"><?php echo e(__('Send SMS')); ?></a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <p><?php echo e(__('Please add mobile no. first from edit profile')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if((Auth::user()->phone_verified == 0) && (!empty(\Illuminate\Support\Facades\Cookie::get('code')))): ?>
                            <div class="form-group">
                                <label for="number"><?php echo e(__('Verify Code')); ?></label>
                                <div class="code-list">
                                    <input name="code" type="text" min="" max=""
                                           class="form-control" id="">
                                </div>
                            </div>
                            <button type="submit"
                                    class="btn profile-edit-btn phn-verify-btn"><?php echo e(__('Verify')); ?></button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/p2p-exchange-web/resources/views/user/profile/include/phone.blade.php ENDPATH**/ ?>