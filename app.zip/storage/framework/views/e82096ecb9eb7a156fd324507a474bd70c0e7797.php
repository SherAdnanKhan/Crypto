<div class="header-bar">
    <div class="table-title">
        <h3><?php echo e(__('Terms and Conditions')); ?></h3>
    </div>
</div>
<div class="profile-info-form">
    <form action="<?php echo e(route('adminSaveTermsCondition')); ?>" method="post"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-12 col-12 mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Terms and Conditions')); ?></label>
                    <textarea name="terms_condition" id="btEditor" cols="30" rows="10" class="form-control"><?php echo e(isset($settings['terms_condition']) ? $settings['terms_condition'] : ''); ?></textarea>
                </div>
            </div>
            <div class="col-lg-12 col-12 mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Privacy Policy')); ?></label>
                    <textarea name="privacy_policy" id="btEditor2" cols="30" rows="10" class="form-control"><?php echo e(isset($settings['privacy_policy']) ? $settings['privacy_policy'] : ''); ?></textarea>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-2 col-12 mt-20">
                <button type="submit" class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH /var/www/html/p2p-exchange-web/resources/views/admin/settings/setting/terms.blade.php ENDPATH**/ ?>