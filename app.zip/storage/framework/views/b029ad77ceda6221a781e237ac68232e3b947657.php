<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-6 mb-xl-0 mb-4">
            <div class="card cp-user-custom-card cp-user-setting-card">
                <div class="card-body">
                    <div class="cp-user-card-header-area">
                        <div class="cp-user-title">
                            <h4><?php echo e(__('Google Authentication Settings')); ?></h4>
                        </div>
                    </div>
                    <div class="cp-user-setting-card-inner">
                        <div class="cp-user-auth-icon">
                            <img src="<?php echo e(asset('assets/user/images/gauth.svg')); ?>" class="img-fluid" alt="">
                        </div>
                        <div class="cp-user-content">
                            <?php if( empty(\Illuminate\Support\Facades\Auth::user()->google2fa_secret)): ?>
                                <a href="javascript:" data-toggle="modal" data-target="#exampleModal" class="btn cp-user-setupbtn"><?php echo e(__('Set up')); ?></a>
                                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <form method="post" action="<?php echo e(route('g2fSecretSave')); ?>">
                                            <input type="hidden" name="google2fa_secret" value="<?php echo e($google2fa_secret); ?>">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Google Authentication')); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-4">
                                                            <img src="<?php echo e($qrcode); ?>" class="img-fluid" alt="">
                                                        </div>
                                                        <div class="col-8">
                                                            <p><?php echo e(__('Open your Google Authenticator app, and scan Your secret code and enter the 6-digit code from the app into the input field')); ?></p>
                                                            <input placeholder="<?php echo e(__('Code')); ?>" type="text" class="form-control" name="code">
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Verify')); ?></button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                                <a href="javascript:" data-toggle="modal" data-target="#exampleModalRemove" class="btn btn-primary"><?php echo e(__('Remove google secret key')); ?></a>
                                <div class="modal fade" id="exampleModalRemove" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <form method="post" action="<?php echo e(route('g2fSecretSave')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="remove" value="1">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('Google Authentication')); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">

                                                        <div class="col-12">
                                                            <p><?php echo e(__('Open your Google Authenticator app and enter the 6-digit code from the app into the input field to remove the google secret key')); ?></p>
                                                            <input placeholder="<?php echo e(__('Code')); ?>" type="text" class="form-control" name="code">
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                                                    <button type="submit" class="btn btn-primary"><?php echo e(__('Verify')); ?></button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="cp-user-content">
                            <h5><?php echo e(__('Security')); ?></h5>
                            <p><?php echo e(__('Please on this option to enable two factor authentication at log In.')); ?></p>
                            <form method="post" action="<?php echo e(route('googleLoginEnable')); ?>">
                                <?php echo csrf_field(); ?>
                                <label class="switch">
                                    <input <?php echo e((\Illuminate\Support\Facades\Auth::user()->g2f_enabled == 1) ? 'checked' : ''); ?> onclick="$(this).closest('form').submit();" type="checkbox">
                                    <span class="slider round"></span>
                                </label>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card cp-user-custom-card cp-user-setting-card">
                <div class="card-body">
                    <div class="cp-user-card-header-area">
                        <div class="cp-user-title">
                            <h4><?php echo e(__('Preference Settings')); ?></h4>
                        </div>
                    </div>
                    <div class="cp-user-setting-card-inner cp-user-setting-card-inner-preference">
                        <div class="cp-user-content">
                            <form method="post" action="<?php echo e(route('savePreference')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label><?php echo e(__('Language')); ?></label>
                                    <div class="cp-user-preferance-setting">
                                        <select name="lang" class="form-control">
                                            <?php $__currentLoopData = language(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(Auth::user()->language == $val): ?> selected <?php endif; ?> value="<?php echo e($val); ?>"><?php echo e(langName($val)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <button class="btn cp-user-setupbtn"><?php echo e(__('Update')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'setting', 'sub_menu'=>'setting'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/user/setting/setting.blade.php ENDPATH**/ ?>