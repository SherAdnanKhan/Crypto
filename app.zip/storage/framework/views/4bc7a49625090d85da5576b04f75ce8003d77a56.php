<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card cp-user-custom-card cp-user-wallet-card">
                <div class="card-body">
                    <div class="cp-user-card-header-area">
                        <div class="cp-user-title">
                            <h4><?php echo e(__('My Wallet')); ?></h4>
                        </div>
                        <div class="buttons">
                            <button class="btn cp-user-add-pocket" data-toggle="modal" data-target="#add-pocket"><?php echo e(__('Add Wallet')); ?></button>
                        </div>
                    </div>
                    <div class="cp-user-wallet-table">
                        <table class="table table-borderless cp-user-custom-table" width="100%">
                            <thead>
                            <tr>
                                <th class="all"><?php echo e(__('Name')); ?></th>
                                <th class="all"><?php echo e(__('Coin Type')); ?></th>
                                <th class="desktop"><?php echo e(__('Balance')); ?></th>
                                <th class="desktop"><?php echo e(__('Referral Balance')); ?></th>
                                <th class="desktop"><?php echo e(__('Updated At')); ?></th>
                                <th class="all"><?php echo e(__('Action')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(isset($wallets[0])): ?>
                                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($wallet->name); ?></td>
                                        <td><?php echo e($wallet->coin_type == 'Default' ? settings('coin_name') : $wallet->coin_type); ?></td>
                                        <td><?php echo e($wallet->balance); ?></td>
                                        <td><?php echo e($wallet->referral_balance); ?></td>
                                        <td><?php echo e($wallet->updated_at); ?></td>
                                        <td>
                                            <ul class="d-flex justify-content-center align-items-center">
                                                <?php if(is_primary_wallet($wallet->id, $wallet->coin_type) == 0): ?>
                                                    <li>
                                                        <a title="<?php echo e(__('Make primary')); ?>" href="<?php echo e(route('makeDefaultAccount',[$wallet->id, $wallet->coin_type])); ?>">
                                                            <img src="<?php echo e(asset('assets/user/images/wallet-table-icons/Key.svg')); ?>" class="img-fluid" alt="">
                                                        </a>
                                                    </li>
                                                <?php endif; ?>
                                                <?php if($wallet->coin_type == 'Default'): ?>

                                                <?php else: ?>
                                                    <li>
                                                        <a title="<?php echo e(__('Deposit')); ?>" href="<?php echo e(route('walletDetails',$wallet->id)); ?>?q=deposit">
                                                            <img src="<?php echo e(asset('assets/user/images/wallet-table-icons/wallet.svg')); ?>" class="img-fluid" alt="">
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a title="<?php echo e(__('withdraw')); ?>" href="<?php echo e(route('walletDetails',$wallet->id)); ?>?q=withdraw">
                                                            <img src="<?php echo e(asset('assets/user/images/wallet-table-icons/send.svg')); ?>" class="img-fluid" alt="">
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a title="<?php echo e(__('Activity log')); ?>" href="<?php echo e(route('walletDetails',$wallet->id)); ?>?q=activity">
                                                            <img src="<?php echo e(asset('assets/user/images/wallet-table-icons/share.svg')); ?>" class="img-fluid" alt="">
                                                        </a>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- add pocket modal -->
    <div class="modal fade cp-user-move-coin-modal" id="add-pocket" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <img src="<?php echo e(asset('assets/user/images/close.svg')); ?>" class="img-fluid" alt="">
                </button>
                <div class="modal-body">
                    <h3><?php echo e(__('Want To Add New Wallet?')); ?></h3>
                    <form method="post" action="<?php echo e(route('createWallet')); ?>" id="walletCreateForm">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label><?php echo e(__('Wallet Name')); ?></label>
                            <input type="text" name="wallet_name" required class="form-control" placeholder="<?php echo e(__('Write Your Wallet Name')); ?>">
                        </div>
                        <div class="form-group">
                            <label><?php echo e(__('Coin Type')); ?></label>
                            <select name="coin_type" id="" required class="form-control">
                                <option value=""><?php echo e(__('Select coin type')); ?></option>
                                <?php if(isset($coins[0])): ?>
                                    <?php $__currentLoopData = $coins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($coin->type); ?>"> <?php echo e($coin->type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-block cp-user-move-btn"><?php echo e(__('Add Wallet')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- move coin modal -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'pocket'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/user/pocket/index.blade.php ENDPATH**/ ?>