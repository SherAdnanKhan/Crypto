<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card cp-user-custom-card">
                <div class="card-body">
                    <div class="cp-user-card-header-area cp-user-card-header-bb">
                        <h4><?php echo e(__('Invite Your Contact')); ?></h4>
                    </div>
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="cp-user-referral-content">
                                <div class="form-group">
                                    <h4 class="cp-user-share-title"><?php echo e(__('Share This Link to Your Contact')); ?></h4>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <button onclick="CopyUrl()" type="button" class="btn copy-url-btn"><?php echo e(__('Copy URL')); ?></button>
                                        </div>
                                        <input type="url" class="form-control" id="url" value="<?php echo e($url); ?>" readonly>
                                    </div>
                                </div>
                                <div class="cp-user-content-bottom">
                                    <span class="cp-user-share-title">or</span>
                                    <h4 class="cp-user-share-title"><?php echo e(__('Share Your Code On')); ?></h4>
                                    <div class="cp-user-share-buttons">
                                        <ul>
                                            <li><a class="fb" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url); ?>" target="_blank"><i class="fa fa-facebook"></i> <?php echo e(__('Facebook')); ?></a></li>
                                            <li><a class="twit" target="_blank" href="http://www.twitter.com/share?url=<?php echo e($url); ?>"><i class="fa fa-twitter"></i> <?php echo e(__('Twitter')); ?></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card cp-user-custom-card mt-5">
                <div class="card-body">
                    <div class="cp-user-card-header-area">
                        <h4><?php echo e(__('My Referrals')); ?></h4>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="cp-user-myreferral">
                                <div class="table-responsive">
                                    <table class="table dataTable cp-user-custom-table table-borderless text-center" width="100%">
                                        <thead>
                                        <tr>
                                            <?php for($i = 1; $i <= 3; $i++): ?>
                                                <th class="referral-level" rowspan="1" colspan="1" aria-label="<?php echo e(__('Level'). ' '. $i); ?>">
                                                    <?php echo e(__('Level'). ' '. $i); ?>

                                                </th>
                                            <?php endfor; ?>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr id="" role="" class="odd">
                                            <?php for($i = 1; $i <= 3; $i++): ?>
                                                <td><?php echo e($referralLevel[$i]); ?></td>
                                            <?php endfor; ?>
                                        </tr>
                                        <tr>
                                            <td colspan="<?php echo e($max_referral_level); ?>"></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card cp-user-custom-card mt-5">
                <div class="card-body">
                    <div class="cp-user-card-header-area">
                        <h4><?php echo e(__('My References')); ?></h4>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="cp-user-myreferral">
                                <div class="table-responsive">
                                    <table class="table dataTable cp-user-custom-table table-borderless text-center" width="100%">
                                        <thead>
                                            <tr>
                                                <th class=""><?php echo e(__('Full Name')); ?></th>
                                                <th class=""><?php echo e(__('Email')); ?></th>
                                                <th class=""><?php echo e(__('Level')); ?></th>
                                                <th class=""><?php echo e(__('Joining Date')); ?></th>
                                                <th class=""><?php echo e(__('Balance')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(isset($referrals)): ?>
                                                <?php $__currentLoopData = $referrals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($data['full_name']); ?></td>
                                                        <td class="email-case"><?php echo e($data['email']); ?></td>
                                                        <td><?php echo e($data['level']); ?></td>
                                                        <td><?php echo e($data['joining_date']); ?></td>
                                                        <td><?php echo e(user_balance($data['id'])); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan=5 class="text-center"><b><?php echo e(__('No data available')); ?></b></td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card cp-user-custom-card mt-5">
                <div class="card-body">
                    <div class="cp-user-card-header-area">
                        <h4><?php echo e(__('My Earnings')); ?></h4>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="cp-user-myreferral">
                                <div class="table-responsive">
                                    <table class="table dataTable cp-user-custom-table table-borderless text-center" width="100%">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(__('Period')); ?></th>
                                                <th><?php echo e(__('Commissions')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $total = 0;
                                            ?>
                                            <?php if(!empty($monthArray)): ?>

                                                <?php $__currentLoopData = $monthArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <?php
                                                            $referral_bonus = isset($monthlyEarningHistories[$key]['total_amount']) ? $monthlyEarningHistories[$key]['total_amount'] : 0;
                                                        ?>
                                                        <td><?php echo e(date('M Y', strtotime($key))); ?></td>
                                                        <td>
                                                            <?php echo e(visual_number_format($referral_bonus)); ?>

                                                            <?php echo e(settings('coin_name')); ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="4" class="text-center"><b><?php echo e(__('No data available')); ?></b></td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>

            function copy_clipboard() {
                var copyText = document.getElementById("myInput");
                copyText.select();
                document.execCommand("Copy");
            }

            function CopyUrl() {

                /* Get the text field */
                var copyText = document.getElementById("url");

                /* Select the text field */
                copyText.select();

                /* Copy the text inside the text field */
                document.execCommand("copy");
                VanillaToasts.create({
                    text: '<?php echo e(__('URL copied successfully')); ?>',
                    type: 'success',
                    timeout: 3000
                });
            }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu'=>'referral'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/user/referral/index.blade.php ENDPATH**/ ?>