<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="custom-breadcrumb">
        <div class="row">
            <div class="col-12">
                <ul>
                    <li class="active-item"><?php echo e(__('Profile')); ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- User Management -->
    <div class="user-management profile">
        <div class="row">
            <div class="col-12">
                <ul class="nav user-management-nav profile-nav mb-3 profile-tab-b" id="pills-tab" role="tablist">
                    <li>
                        <a class=" <?php if(isset($tab) && $tab=='profile'): ?> active <?php endif; ?> nav-link " data-id="profile" data-toggle="pill" role="tab" data-controls="profile" aria-selected="true" href="#profile">
                            <img src="<?php echo e(asset('assets/admin/images/user-management-icons/user.svg')); ?>" class="img-fluid" alt="">
                            <span><?php echo e(__('My Profile')); ?></span>
                        </a>
                    </li>
                    <li>
                        <a class=" <?php if(isset($tab) && $tab=='edit_profile'): ?> active <?php endif; ?> nav-link  " data-id="edit_profile" data-toggle="pill" role="tab" data-controls="edit_profile" aria-selected="true" href="#edit_profile">
                            <img src="<?php echo e(asset('assets/admin/images/edit-profile.svg')); ?>" class="img-fluid" alt="">
                            <span><?php echo e(__('Edit Profile')); ?></span>
                        </a>
                    </li>
                    <li>
                        <a class=" <?php if(isset($tab) && $tab=='change_pass'): ?> active <?php endif; ?> nav-link  " data-id="change_pass" data-toggle="pill" role="tab" data-controls="change_pass" aria-selected="true" href="#change_pass">
                            <img src="<?php echo e(asset('assets/admin/images/reset-pass.svg')); ?>" class="img-fluid" alt="">
                            <span><?php echo e(__('Change Password')); ?></span>
                        </a>
                    </li>
                </ul>
                <div class="tab-content tab-pt-n" id="tabContent">
                    <!-- genarel-setting start-->
                    <div class="tab-pane fade show <?php if(isset($tab) && $tab=='profile'): ?>  active <?php endif; ?> " id="profile" role="tabpanel" aria-labelledby="general-setting-tab">
                        <div class="form-area plr-65">
                            <h4 class="mb-4"><?php echo e(__('My Profile')); ?></h4>
                            <div class="row">
                                <div class="col-lg-5">
                                    <div class="profile-img-area pro-img text-center">
                                        <div class="prifile-img">
                                            <img width="100" src="<?php echo e(show_image(Auth::user()->id,'user')); ?>" alt="profile">
                                        </div>
                                        <div class="profile-name">
                                            <h3><?php echo clean(Auth::user()->first_name.' '.Auth::user()->last_name); ?></h3>
                                            <span><?php echo clean(Auth::user()->email); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 offset-lg-1">
                                    <div class="profile-info">
                                        <div class="table-responsive">
                                            <table class="table table-striped">
                                                <tbody>
                                                <tr>
                                                    <td><?php echo e(__('Name')); ?></td>
                                                    <td>:</td>
                                                    <td><span><?php echo clean(Auth::user()->first_name.' '.Auth::user()->last_name); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo e(__('Role')); ?></td>
                                                    <td>:</td>
                                                    <td><span><?php echo e(userRole($user->role)); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo e(__('Email')); ?></td>
                                                    <td>:</td>
                                                    <td><span><?php echo clean(Auth::user()->email); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo e(__('Email verification')); ?></td>
                                                    <td>:</td>
                                                    <td><span class="color"><?php echo e(statusAction($user->is_verified)); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo e(__('Contact')); ?></td>
                                                    <td>:</td>
                                                    <td><span><?php echo e(\Illuminate\Support\Facades\Auth::user()->phone); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td><?php echo e(__('Status')); ?></td>
                                                    <td>:</td>
                                                    <td><span><?php echo e(statusAction($user->status)); ?></span></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade <?php if(isset($tab) && $tab=='edit_profile'): ?>show active <?php endif; ?>" id="edit_profile" role="tabpanel" aria-labelledby="apisetting-tab">
                        <div class="form-area">
                            <h4 class="mb-4"><?php echo e(__('Edit Profile')); ?></h4>
                            <div class="row">
                                <div class="col-lg-5">
                                    <div class="profile-img-area text-center">
                                        <div class="uplode-img">
                                            <form enctype="multipart/form-data" method="post" action="<?php echo e(route('uploadProfileImage')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div id="file-upload" class="section-p">
                                                    <input type="file" name="file_one" value="" id="file" ref="file" class="dropify" data-default-file="<?php echo e(show_image(Auth::user()->id,'user')); ?>" />
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-7">
                                    <div class="profile-info-form form-area  p-0">
                                        <form action="<?php echo e(route('UserProfileUpdate')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="firstname"><?php echo e(__('First Name')); ?></label>
                                                <input name="first_name" value="<?php echo e(old('first_name',Auth::user()->first_name)); ?>" type="text" class="form-control" id="firstname" placeholder="<?php echo e(__('First name')); ?>">
                                                <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="lastname"><?php echo e(__('Last Name')); ?></label>
                                                <input name="last_name" value="<?php echo e(old('last_name',Auth::user()->last_name)); ?>" type="text" class="form-control" id="lastname" placeholder="<?php echo e(__('Last name')); ?>">
                                                <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="email"><?php echo e(__('Phone Number')); ?></label>
                                                <input name="phone"   type="text" value="<?php echo e(old('phone',Auth::user()->phone)); ?>" class="form-control" id="phoneVerify" placeholder="<?php echo e(__('01999999999')); ?>">
                                                <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="email"><?php echo e(__('Email')); ?></label>
                                                <input name="" readonly type="email" value="<?php echo e(old('email',Auth::user()->email)); ?>" class="form-control" id="email" placeholder="<?php echo e(__('email')); ?>">
                                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                            </div>
                                            <button type="submit" class="btn"><?php echo e(__('Update')); ?></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade <?php if(isset($tab) && $tab=='change_pass'): ?>show active <?php endif; ?>" id="change_pass" role="tabpanel" aria-labelledby="braintree-tab">
                        <div class="form-area ">
                            <h4 class="mb-4"><?php echo e(__('Change Password')); ?></h4>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="profile-info-form form-area p-0">
                                        <form method="POST" action="<?php echo e(route('changePasswordSave')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="currentpassword"><?php echo e(__('Current Password')); ?></label>
                                                <input name="password" type="password" class="form-control" id="currentpassword" placeholder="">
                                                <span class="flaticon-look"></span>
                                            </div>
                                            <div class="form-group">
                                                <label for="newpassword"><?php echo e(__('New Password')); ?></label>
                                                <input name="new_password" type="password" class="form-control" id="newpassword" placeholder="">
                                                <span class="flaticon-look"></span>
                                            </div>
                                            <div class="form-group">
                                                <label for="confirmpassword"><?php echo e(__('Confirm Password')); ?></label>
                                                <input name="confirm_new_password" type="password" class="form-control" id="confirmpassword" placeholder="">
                                                <span class="flaticon-look"></span>
                                            </div>
                                            <button type="submit" class="btn"><?php echo e(__('Change Password')); ?></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /User Management -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        (function($) {
            "use strict";

            $('.nav-link').on('click', function () {
                var query = $(this).data('id');
                window.history.pushState('page2', 'Title', '<?php echo e(route('adminProfile')); ?>?tab=' + query);
                $('.nav-link').removeClass('active');
                $(this).addClass('active');
                var str = '#' + $(this).data('controls');
                $('.tab-pane').removeClass('show active');
                $(str).addClass('show active');
            });

            jQuery("#file").on('change',function () {
                this.form.submit();

            });

            $(function () {
                $(document.body).on('submit', '.Upload', function (e) {
                    e.preventDefault();
                    $('.error_msg').addClass('d-none');
                    $('.succ_msg').addClass('d-none');
                    var form = $(this);
                    $.ajax({
                        type: "POST",
                        enctype: 'multipart/form-data',
                        url: form.attr('action'),
                        data: new FormData($(this)[0]),
                        async: false,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function (data) {
                            if (data.success == true) {
                                $('.succ_msg').removeClass('d-none');
                                $('.succ_msg').html(data.message);
                            } else {

                                $('.error_msg').removeClass('d-none');
                                $('.error_msg').html(data.message);

                            }
                        }
                    });
                    return false;
                });
            });
        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master',['menu'=>'profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/admin/profile/index.blade.php ENDPATH**/ ?>