<div class="header-bar">
    <div class="table-title">
        <h3><?php echo e(__('Referral Settings')); ?></h3>
    </div>
</div>
<div class="profile-info-form">
    <form method="post" action="<?php echo e(route('adminReferralFeesSettings')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-12 col-12  mt-20">
                <div class="form-group">
                    <label
                        class=""><?php echo e(__('Maximum Affiliation Level : ')); ?> 3</label>
                </div>
            </div>
            <?php for($i = 1; $i <=3 ; $i ++): ?>
                <div class="col-lg-6 col-12  mt-20">
                    <div class="form-group">
                        <label for="#"><?php echo e(__('Level')); ?> <?php echo e($i); ?> (%)</label>
                        <?php ( $slug_name = 'fees_level'.$i); ?>
                        <p class="fees-wrap">
                            <input type="text" class="number_only form-control"
                                   name="<?php echo e($slug_name); ?>"
                                   value="<?php echo e(old($slug_name, isset($settings[$slug_name]) ? $settings[$slug_name] : 0)); ?>">
                            <span>%</span>
                        </p>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
        <div class="row">
            <div class="col-lg-2 col-12 mt-20">
                <button class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/admin/settings/setting/referral.blade.php ENDPATH**/ ?>