<div class="header-bar">
    <div class="table-title">
        <h3><?php echo e(__('Twillo Setup')); ?></h3>
    </div>
</div>
<div class="profile-info-form">
    <form action="<?php echo e(route('adminSaveSmsSettings')); ?>" method="post"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Twillo SID')); ?></label>
                    <input class="form-control" type="text" name="twillo_secret_key"
                           placeholder="<?php echo e(__('Secret SID')); ?>"
                           value="<?php echo e($settings['twillo_secret_key']); ?>">
                </div>
            </div>
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Twillo Token')); ?></label>
                    <input class="form-control" type="text" name="twillo_auth_token"
                           placeholder="<?php echo e(__('Auth Token')); ?>"
                           value="<?php echo e($settings['twillo_auth_token']); ?>">
                </div>
            </div>
            <div class="col-lg-6 col-12  mt-20">
                <div class="form-group">
                    <label for="#"><?php echo e(__('Twillo From')); ?></label>
                    <input class="form-control" type="text" name="twillo_number"
                           placeholder="<?php echo e(__('From number')); ?>"
                           value="<?php echo e(isset($settings['twillo_number']) ? $settings['twillo_number'] : ''); ?>">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-2 col-12 mt-20">
                <button type="submit" class="button-primary theme-btn"><?php echo e(__('Update')); ?></button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH /var/www/html/p2p-exchange-web/resources/views/admin/settings/setting/twillo.blade.php ENDPATH**/ ?>