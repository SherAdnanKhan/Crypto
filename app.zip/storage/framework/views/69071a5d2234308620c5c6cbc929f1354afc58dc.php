<div class="card cp-user-custom-card">
    <div class="card-body">
        <div class="cp-user-profile-header">
            <h5><?php echo e(__('All Activity List')); ?></h5>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="cp-user-wallet-table table-responsive">
                    <table id="activity-tbl" class="table table-borderless cp-user-custom-table"
                           width="100%">
                        <thead>
                        <tr>
                            <th class="all"><?php echo e(__('Action')); ?></th>
                            <th class="desktop"><?php echo e(__('Source')); ?></th>
                            <th class="desktop"><?php echo e(__('IP Address')); ?></th>
                            
                            <th class="all"><?php echo e(__('Updated At')); ?></th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\wamp64\www\p2p-exchange-web\p2p-exchange-web\resources\views/user/profile/include/activity.blade.php ENDPATH**/ ?>