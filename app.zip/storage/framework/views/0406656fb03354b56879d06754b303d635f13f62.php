<?php $__env->startSection('title', isset($title) ? $title : __('Login')); ?>

<?php $__env->startSection('content'); ?>
    <div class="user-content-wrapper">
        <div>
            <div class="user-form">
                <div class="right">
                    <div class="form-top">
                        <a class="auth-logo" href="javascript:">
                            <img src="<?php echo e(show_image(1,'login_logo')); ?>" class="img-fluid" alt="">
                        </a>
                        <p><?php echo e(__('Log into your account')); ?></p>
                    </div>
                    <?php echo e(Form::open(['route' => 'loginProcess', 'files' => true])); ?>

                    <div class="form-group">
                        <label><?php echo e(__('Email address')); ?></label>
                        <input type="email" value="<?php echo e(old('email')); ?>" id="exampleInputEmail1" name="email"
                               class="form-control" placeholder="<?php echo e(__('Your email here')); ?>">
                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <p class="invalid-feedback"><?php echo e($message); ?> </p>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(__('Password')); ?></label>
                        <input type="password" name="password" id="exampleInputPassword1"
                               class="form-control form-control-password look-pass-a"
                               placeholder="<?php echo e(__('Your password here')); ?>">
                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                        <p class="invalid-feedback"><?php echo e($message); ?> </p>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        <span class="eye"><i class="fa fa-eye-slash toggle-password"></i></span>
                    </div>
                    <div class="d-flex justify-content-between rememberme align-items-center mb-4">
                        <div>
                            <div class="form-group form-check mb-0">
                                <input class="styled-checkbox form-check-input" id="styled-checkbox-1" type="checkbox"
                                       value="value1">
                            </div>
                        </div>
                        <div class="text-right"><a href="<?php echo e(route('forgotPassword')); ?>"><?php echo e(__('Forgot Password?')); ?></a>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary nimmu-user-sibmit-button"><?php echo e(__('Login')); ?></button>
                    <?php echo e(Form::close()); ?>

                    <div class="form-bottom text-center">
                        <p><?php echo e(__("Don't have an account?")); ?> <a href="<?php echo e(route('signUp')); ?>"><?php echo e(__('Sign Up')); ?></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        (function($) {
            "use strict";

            $(".toggle-password").on('click',function () {
                $(this).toggleClass("fa-eye-slash fa-eye");
            });

            $(".eye").on('click', function () {
                var $pwd = $(".look-pass-a");
                if ($pwd.attr('type') === 'password') {
                    $pwd.attr('type', 'text');
                } else {
                    $pwd.attr('type', 'password');
                }
            });
        })(jQuery);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.master',['menu'=>'dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/p2p-exchange-web/resources/views/auth/login.blade.php ENDPATH**/ ?>