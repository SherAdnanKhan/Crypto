<?php $__env->startSection('title', isset($title) ? $title : ''); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card cp-user-custom-card cp-user-deposit-card">
        <div class="row">
            <div class="col-sm-12">
                <div class="wallet-inner">
                    <div class="wallet-content card-body">
                        <div class="wallet-top cp-user-card-header-area">
                            <div class="title">
                                <div class="wallet-title text-center">
                                    <h4>
                                        <a href="<?php echo e(route('createOffer')); ?>"><button class="btn theme-btn"><?php echo e(__('Create Offer')); ?></button></a>
                                    </h4>
                                </div>
                            </div>
                        </div>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade  show active in"
                                 id="activity" role="tabpanel" aria-labelledby="activity-tab">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="activity-area">
                                            <div class="activity-top-area">
                                                <div class="cp-user-card-header-area">
                                                    <div class="title">
                                                        <h4 id="list_title"><?php echo e(__('All Buy Offer List')); ?></h4>
                                                    </div>
                                                    <div class="deposite-tabs cp-user-deposit-card">
                                                        <div class="activity-right text-right">
                                                            <ul class="nav cp-user-profile-nav mb-0">
                                                                <li class="nav-item">
                                                                    <a class="nav-link active" data-toggle="tab" onclick="$('#list_title').html('All Buy Offer List')" data-title="" href="#Deposit"><?php echo e(__('Buy Offer')); ?></a>
                                                                </li>
                                                                <li class="nav-item">
                                                                    <a class="nav-link" data-toggle="tab" onclick="$('#list_title').html('All Sell Offer List')" href="#Withdraw"><?php echo e(__('Sell Offer')); ?></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="activity-list">
                                                <div class="tab-content">
                                                    <div id="Deposit" class="tab-pane fade show in active">

                                                        <div class="cp-user-wallet-table table-responsive">
                                                            <table class="table">
                                                                <thead>
                                                                <tr>
                                                                    <th><?php echo e(__('Buying Coin Type')); ?></th>
                                                                    <th><?php echo e(__('Headline')); ?></th>
                                                                    <th><?php echo e(__('Location')); ?></th>
                                                                    <th><?php echo e(__('Rate')); ?></th>
                                                                    <th><?php echo e(__('Status')); ?></th>
                                                                    <th><?php echo e(__('Created At')); ?></th>
                                                                    <th><?php echo e(__('Actions')); ?></th>
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                <?php if(isset($buys[0])): ?>
                                                                    <?php $__currentLoopData = $buys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td><?php echo e($buy->coin_type); ?></td>
                                                                            <td><?php echo e(\Illuminate\Support\Str::limit($buy->headline,10)); ?></td>
                                                                            <td><?php echo e(countrylist($buy->country)); ?></td>
                                                                            <td>
                                                                                <?php if($buy->rate_type == RATE_TYPE_DYNAMIC): ?>
                                                                                    <?php echo e(number_format($buy->rate_percentage,2)); ?> % <?php echo e(price_rate_type($buy->price_type)); ?> <?php echo e(__(' Market')); ?>

                                                                                <?php else: ?>
                                                                                    <?php echo e($buy->coin_rate.' '.$buy->currency); ?>

                                                                                <?php endif; ?>
                                                                            </td>
                                                                            <td><?php echo e(offer_active_status($buy->status)); ?></td>
                                                                            <td><?php echo e($buy->created_at); ?></td>
                                                                            <td>
                                                                                <ul class="d-flex activity-menu">
                                                                                    <li class="viewuser"><a title="<?php echo e(__('Edit')); ?>" href="<?php echo e(route('editOffer', [($buy->unique_code),BUY])); ?>"><i class="fa fa-pencil"></i></a></li>

                                                                                    <?php if($buy->status != STATUS_ACTIVE): ?>
                                                                                        <li class="deleteuser">
                                                                                            <a title="<?php echo e(__('Activate')); ?>" href="#active_buy<?php echo e(($buy->id)); ?>" data-toggle="modal">
                                                                                                <span><img src="<?php echo e(asset("assets/admin/images/user-management-icons/activity/cancel.svg")); ?>" class="img-fluid" alt=""></span>
                                                                                            </a>
                                                                                        </li>
                                                                                        <div id="active_buy<?php echo e(($buy->id)); ?>" class="modal fade delete" role="dialog">
                                                                                            <div class="modal-dialog modal-md">
                                                                                                <div class="modal-content">
                                                                                                    <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Activate')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                                                    <div class="modal-body"><p><?php echo e(__('Do you want to activate again ?')); ?></p></div>
                                                                                                    <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                                                        <a class="btn btn-success" href="<?php echo e(route('activateOffer', [($buy->id),BUY])); ?>"><?php echo e(__('Confirm')); ?></a>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    <?php else: ?>
                                                                                        <li class="deleteuser">
                                                                                            <a title="<?php echo e(__('Deactivate')); ?>" href="#deactive_buy<?php echo e(($buy->id)); ?>" data-toggle="modal">
                                                                                                <span><img src="<?php echo e(asset("assets/admin/images/user-management-icons/activity/activate.svg")); ?>" class="img-fluid" alt=""></span>
                                                                                            </a>
                                                                                        </li>
                                                                                        <div id="deactive_buy<?php echo e(($buy->id)); ?>" class="modal fade delete" role="dialog">
                                                                                            <div class="modal-dialog modal-md">
                                                                                                <div class="modal-content">
                                                                                                    <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Deactive')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                                                    <div class="modal-body"><p><?php echo e(__('Do you want to deactive ?')); ?></p></div>
                                                                                                    <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                                                        <a class="btn btn-danger" href="<?php echo e(route('deactiveOffer', [($buy->id),BUY])); ?>"><?php echo e(__('Confirm')); ?></a>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    <?php endif; ?>
                                                                                </ul>
                                                                            </td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php else: ?>
                                                                    <tr>
                                                                        <td colspan="7" class="text-center"><?php echo e(__('No data available')); ?></td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                                </tbody>
                                                            </table>
                                                            <?php if(isset($buys[0])): ?>
                                                                <div class="pull-right address-pagin">
                                                                    <?php echo e($buys->appends(request()->input())->links()); ?>

                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div id="Withdraw" class="tab-pane fade in ">

                                                        <div class="cp-user-wallet-table table-responsive">
                                                            <table class="table">
                                                                <thead>
                                                                <tr>
                                                                    <th><?php echo e(__('Selling Coin Type')); ?></th>
                                                                    <th><?php echo e(__('Headline')); ?></th>
                                                                    <th><?php echo e(__('Location')); ?></th>
                                                                    <th><?php echo e(__('Rate')); ?></th>
                                                                    <th><?php echo e(__('Status')); ?></th>
                                                                    <th><?php echo e(__('Created At')); ?></th>
                                                                    <th><?php echo e(__('Actions')); ?></th>
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                <?php if(isset($sells[0])): ?>
                                                                    <?php $__currentLoopData = $sells; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td><?php echo e($sell->coin_type); ?></td>
                                                                            <td><?php echo e(\Illuminate\Support\Str::limit($sell->headline,10)); ?></td>
                                                                            <td><?php echo e(countrylist($sell->country)); ?></td>
                                                                            <td>
                                                                                <?php if($sell->rate_type == RATE_TYPE_DYNAMIC): ?>
                                                                                    <?php echo e(number_format($sell->rate_percentage,2)); ?> % <?php echo e(price_rate_type($sell->price_type)); ?> <?php echo e(__(' Market')); ?>

                                                                                <?php else: ?>
                                                                                    <?php echo e(number_format($sell->coin_rate,2).' '.$sell->currency); ?>

                                                                                <?php endif; ?>
                                                                            </td>
                                                                            <td><?php echo e(offer_active_status($sell->status)); ?></td>
                                                                            <td><?php echo e($sell->created_at); ?></td>
                                                                            <td>
                                                                                <ul class="d-flex activity-menu">
                                                                                    <li class="viewuser"><a title="<?php echo e(__('Edit')); ?>" href="<?php echo e(route('editOffer', [($sell->unique_code), SELL])); ?>"><i class="fa fa-pencil"></i></a></li>
                                                                                    <?php if($sell->status != STATUS_ACTIVE): ?>
                                                                                        <li class="deleteuser">
                                                                                            <a title="<?php echo e(__('Activate')); ?>" href="#active_sell<?php echo e(($sell->id)); ?>" data-toggle="modal">
                                                                                                <span><img src="<?php echo e(asset("assets/admin/images/user-management-icons/activity/cancel.svg")); ?>" class="img-fluid" alt=""></span>
                                                                                            </a>
                                                                                        </li>
                                                                                        <div id="active_sell<?php echo e(($sell->id)); ?>" class="modal fade delete" role="dialog">
                                                                                            <div class="modal-dialog modal-md">
                                                                                                <div class="modal-content">
                                                                                                    <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Activate')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                                                    <div class="modal-body"><p><?php echo e(__('Do you want to activate again ?')); ?></p></div>
                                                                                                    <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                                                        <a class="btn btn-success" href="<?php echo e(route('activateOffer', [($sell->id), SELL])); ?>"><?php echo e(__('Confirm')); ?></a>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    <?php else: ?>
                                                                                        <li class="deleteuser">
                                                                                            <a title="<?php echo e(__('Deactivate')); ?>" href="#deactive_sell<?php echo e(($sell->id)); ?>" data-toggle="modal">
                                                                                                <span><img src="<?php echo e(asset("assets/admin/images/user-management-icons/activity/activate.svg")); ?>" class="img-fluid" alt=""></span>
                                                                                            </a>
                                                                                        </li>
                                                                                        <div id="deactive_sell<?php echo e(($sell->id)); ?>" class="modal fade delete" role="dialog">
                                                                                            <div class="modal-dialog modal-md">
                                                                                                <div class="modal-content">
                                                                                                    <div class="modal-header"><h6 class="modal-title"><?php echo e(__('Deactive')); ?></h6><button type="button" class="close" data-dismiss="modal">&times;</button></div>
                                                                                                    <div class="modal-body"><p><?php echo e(__('Do you want to deactive ?')); ?></p></div>
                                                                                                    <div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__("Close")); ?></button>
                                                                                                        <a class="btn btn-danger" href="<?php echo e(route('deactiveOffer', [($sell->id),SELL])); ?>"><?php echo e(__('Confirm')); ?></a>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    <?php endif; ?>
                                                                                </ul>
                                                                            </td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php else: ?>
                                                                    <tr>
                                                                        <td colspan="7"
                                                                            class="text-center"><?php echo e(__('No data available')); ?></td>
                                                                    </tr>
                                                                <?php endif; ?>
                                                                </tbody>
                                                            </table>
                                                            <?php if(isset($sells[0])): ?>
                                                                <div class="pull-right address-pagin">
                                                                    <?php echo e($sells->appends(request()->input())->links()); ?>

                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master',['menu' => 'offer'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/user/marketplace/offer/offer_list.blade.php ENDPATH**/ ?>