<?php echo $__env->make('email.header_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h3><?php echo e(__('Hello')); ?>, <?php echo e($data->first_name.' '.$data->last_name); ?></h3>
<p>
    <?php echo e(__('We need to verify your email address. In order to verify your account please click on the following link or paste the link on address bar of your browser and hit -')); ?>

</p>
<p>
    <a style="text-decoration: none;background: #4A9A4D;color: #fff;padding: 5px 10px;border-radius: 3px;" href="<?php echo e(route('verifyWeb').'?token='.encrypt($key).'&email='.$data->email); ?>"><?php echo e(__('Verify')); ?></a>
</p>
<p>
    <?php echo e(__('Thanks a lot for being with us.')); ?> <br/>
    <?php echo e(allSetting()['app_title']); ?>

</p>
<?php echo $__env->make('email.footer_new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/p9zexgpyv5lk/tradeux.com/exchange/resources/views/email/verifyWeb.blade.php ENDPATH**/ ?>